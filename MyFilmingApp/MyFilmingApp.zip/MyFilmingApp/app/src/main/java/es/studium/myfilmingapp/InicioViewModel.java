package es.studium.myfilmingapp;

import androidx.lifecycle.ViewModel;

public class InicioViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}